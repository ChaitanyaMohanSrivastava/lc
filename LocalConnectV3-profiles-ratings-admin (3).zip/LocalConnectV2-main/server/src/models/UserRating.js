import mongoose from "mongoose";

/**
 * Person-to-person star rating (1-5) that builds a user's account rating.
 *
 *  customer_to_provider : the buyer / customer rates the service provider (listing owner)
 *  provider_to_customer : the service provider rates the customer
 *
 * A rating can only be given for a real interaction: an ACCEPTED request between the two people.
 * One rating per direction per request (it can be edited, never duplicated).
 */
const userRatingSchema = new mongoose.Schema(
  {
    raterId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
    raterName: { type: String, required: true, trim: true },
    ratedUserId: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true, index: true },
    direction: { type: String, enum: ["customer_to_provider", "provider_to_customer"], required: true, index: true },
    requestId: { type: mongoose.Schema.Types.ObjectId, ref: "Request", required: true, index: true },
    listingId: { type: mongoose.Schema.Types.ObjectId, ref: "Listing", default: undefined },
    listingTitle: { type: String, default: "", trim: true },
    rating: { type: Number, required: true, min: 1, max: 5 },
    comment: { type: String, default: "", trim: true, maxlength: 500 },
    // Quick labels the rater picked (see RATING_TAGS). Unknown tags are dropped by the route.
    tags: { type: [String], default: [] },
    // Would the rater deal with this person again?
    wouldRecommend: { type: Boolean, default: undefined },
  },
  { timestamps: true }
);

// One rating per person, per request, per direction.
userRatingSchema.index({ raterId: 1, requestId: 1, direction: 1 }, { unique: true });

export const UserRating = mongoose.model("UserRating", userRatingSchema);

/** Quick labels a rater can attach, split by who is being rated. */
export const RATING_TAGS = {
  provider: ["Responsive", "Honest", "Fair price", "Clean & as described", "On time", "Helpful"],
  customer: ["Polite", "Paid on time", "Respectful", "Clear communication", "Took good care", "Easy to deal with"],
};
export const ALL_RATING_TAGS = [...RATING_TAGS.provider, ...RATING_TAGS.customer];

/**
 * Average + count of ratings a user has RECEIVED in one direction (or both when direction is omitted).
 * Also returns the 1-5 star distribution, the most common tags and the share of people who would recommend.
 */
export async function summarizeRatings(userId, direction = null) {
  const match = { ratedUserId: new mongoose.Types.ObjectId(String(userId)) };
  if (direction) match.direction = direction;
  const rows = await UserRating.find(match).select("rating tags wouldRecommend").lean();

  const distribution = { 1: 0, 2: 0, 3: 0, 4: 0, 5: 0 };
  const tagCounts = new Map();
  let sum = 0;
  let recYes = 0;
  let recAnswered = 0;
  for (const r of rows) {
    sum += r.rating;
    distribution[r.rating] = (distribution[r.rating] || 0) + 1;
    for (const t of r.tags || []) tagCounts.set(t, (tagCounts.get(t) || 0) + 1);
    if (typeof r.wouldRecommend === "boolean") {
      recAnswered += 1;
      if (r.wouldRecommend) recYes += 1;
    }
  }
  const count = rows.length;
  return {
    average: count ? Math.round((sum / count) * 10) / 10 : 0,
    count,
    distribution,
    topTags: [...tagCounts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 4).map(([tag, n]) => ({ tag, count: n })),
    recommendPercent: recAnswered ? Math.round((recYes / recAnswered) * 100) : null,
  };
}
